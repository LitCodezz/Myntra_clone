const carouselSlide = document.querySelector('.carousel-slide');
const images = document.querySelectorAll('.carousel-slide img');
const carouselNav = document.querySelector('.carousel-nav');

let slideIndex = 0;
const slideWidth = images[0].clientWidth; // Get the width of a single slide

// Move the carousel to the next slide
function nextSlide() {
  slideIndex++;
  if (slideIndex >= images.length) {
    slideIndex = 0; // Reset index when reaching the end
  }
  updateSlidePosition();
  updateIndicators();
}

// Update the carousel's position to show the correct slide
function updateSlidePosition() {
  carouselSlide.style.transform = `translateX(-${slideWidth * slideIndex}px)`;
}
function updateIndicators() {
  // Remove the "active" class from all indicators
  const indicators = carouselNav.getElementsByTagName('button');
  for (let i = 0; i < indicators.length; i++) {
    indicators[i].classList.remove('active');
  }

  // Add the "active" class to the current indicator
  indicators[slideIndex].classList.add('active');
}

// Generate carousel navigation indicators
function createIndicators() {
  for (let i = 0; i < images.length; i++) {
    const indicator = document.createElement('button');
    indicator.addEventListener('click', () => {
      slideIndex = i;
      updateSlidePosition();
      updateIndicators();
    });
    carouselNav.appendChild(indicator);
  }

  // Set the first indicator as active by default
  updateIndicators();
}

// Start the carousel sliding automatically
setInterval(nextSlide, 3000); //
createIndicators();
function toggleMenu() {
  var menu = document.getElementById('main-menu');
  menu.classList.toggle('active');
}